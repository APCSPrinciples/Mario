local background = display.newImage("Background.png", 285,160)
local ground = display.newImage("Ground.png",285,305)
local cloud1 = display.newImage("cloud.png",285,100)
local cloud2 = display.newImage("cloud.png",85,70)