application = 
{
	content = 
	{ 
		width = 320,
		height = 570, 
		scale = "letterbox"
	}
}